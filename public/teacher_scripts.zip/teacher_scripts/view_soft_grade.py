import matplotlib.pyplot as plt
import json 
import numpy as np

STUDENT_ID = "REPLACE WITH STUDENT ID"

def load_data(filename):
    with open(filename) as f:
        data = json.load(f)
    return data

def plot_grade_belief(grade_belief):
    std_dev = round(np.std(grade_belief), 3)
    plt.hist(grade_belief, bins=20, alpha=0.5, label='Soft Grade') 
    plt.xlim(0, 1)
    plt.xlabel('Grade')
    plt.ylabel('Frequency')
    plt.title(f'Soft Grade Belief Distribution for \n Student: {STUDENT_ID}')
    plt.legend(loc="upper left")

    # add a text box to the plot with the standard deviation
    plt.text(0.5, 0.5, f'Standard Deviation: {std_dev}', horizontalalignment='center', verticalalignment='center', transform=plt.gca().transAxes)
    
    plt.show()


def main():
    data = load_data("soft_grades.json")

    # get student with a specific student_id
    student_soft_grade = data[STUDENT_ID]

    plot_grade_belief(student_soft_grade)

if __name__ == "__main__":
    main()