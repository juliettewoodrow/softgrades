#!/usr/bin/env python3
"""
This script computes soft grade beliefs for students based on a CSV file.
The CSV should have one student per row. One column contains the student id
(e.g. "student_id") and the remaining columns are assessment scores (normalized 0–1).

Usage:
    python compute_soft_grades.py <path_to_csv_file>

The teacher will be prompted to enter a comma-separated list of assessment column names.
The script outputs a JSON file "soft_grades.json" where each key is a student id
and the value is the computed soft grade belief list.
"""

import sys
import os
import pandas as pd
import numpy as np
import math
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
import tensorflow_probability as tfp
from scipy.optimize import minimize
import scipy.stats as stats

# -------------------------------
# Functions for Parameter Estimation
# -------------------------------

def approx_moments(d, s):
    X = tfp.distributions.LogitNormal(-d, s)
    mu_approx = X.mean_approx().numpy()
    std_approx = X.stddev_approx().numpy()
    return mu_approx, std_approx

def objective(params, mu, std, _):
    d, log_var = params
    var = np.exp(log_var)
    std_dev = np.sqrt(var)
    mu_approx, std_approx = approx_moments(d, std_dev)
    loss = (mu - mu_approx)**2 + (std - std_approx)**2
    return loss

def estimate_parameters(mu, std, prior_ability_std):
    best_result = None
    best_loss = float('inf')
    for i in range(3):
        initial_guess = (np.random.uniform(-10, 10), np.log(np.random.uniform(0.001, 5)))
        result = minimize(objective, initial_guess, args=(mu, std, 0), method='L-BFGS-B', options={'ftol': 1e-6, 'gtol': 1e-6, 'maxiter': 1000})
        if result.fun < best_loss:
            best_loss = result.fun
            best_result = result
    d_opt, log_epsilon_squared_opt = best_result.x
    epsilon_squared_opt = np.exp(log_epsilon_squared_opt)
    distance = best_result.fun
    return d_opt, epsilon_squared_opt, distance

def estimate_stats(observed, _, alpha=1):
    assn_stats = observed['assignment_stats']
    difficulties = []
    logit_vars = []
    total_distance = []
    for i in assn_stats.keys():
        mu_grade = assn_stats[i]['mean']
        std_grade = assn_stats[i]['std']
        assn_d, logit_var, distance = estimate_parameters(mu_grade, std_grade, _)
        difficulties.append(assn_d)
        logit_vars.append(logit_var)
        total_distance.append(distance)
    course_min_vj = min(logit_vars)
    prior_ability_std = min(alpha * course_min_vj, max(np.sqrt(course_min_vj) - 0.01, 0.01))
    epsilons = [np.sqrt(logit_vars[i] - prior_ability_std**2) for i in range(len(logit_vars))]
    class_stats = {
        'difficulties': difficulties,
        'assn_epsilons': epsilons,
        'S': prior_ability_std
    }
    return class_stats, total_distance

# -------------------------------
# Functions for Ability Inference
# -------------------------------

def sigmoid(x):
    # check for overflow in np.exp(-x)
    if x > 100:
        print("X value is large!", x)
    return 1 / (1 + np.exp(-x))

def logit(x):
    return np.log(x / (1 - x))

def gaussian_posterior(obs, vars, S):
    mu_prior = 0
    weighted_sum = sum(o / v for o, v in zip(obs, vars))
    sum_inverse_variances = sum(1 / v for v in vars)
    mu_post = (mu_prior / S ** 2 + weighted_sum) / (1 / S ** 2 + sum_inverse_variances)
    sigma_post_squared = 1 / (1 / S ** 2 + sum_inverse_variances)
    return mu_post, sigma_post_squared

def estimate_ability(scores, difficulties, epsilons, S, i):
    ability_samples = []
    variances = []
    for j in range(len(scores)):
        grade = scores[j]
        if grade is None:
            print("WARNING: No grade for student", i, "assignment", j)
            continue

        difficulty, epsilon = difficulties[j], epsilons[j]
        sample = logit(grade) + difficulty
        ability_samples.append(sample)
        variances.append(epsilon ** 2)
    std_dev_ability = S
    ability_mu, ability_var = gaussian_posterior(ability_samples, variances, std_dev_ability)
    ability_std = math.sqrt(ability_var)
    return {
        'mu': ability_mu,
        'std': ability_std
    }

def estimate_student_abilities(observed, class_stats):
    student_abilities = {}
    difficulties = class_stats['difficulties']
    epsilons = class_stats['assn_epsilons']
    for i in observed['students']:
        scores = observed['students'][i]['scores']
        ability = estimate_ability(scores, difficulties, epsilons, class_stats['S'], i)
        student_abilities[i] = ability
    return student_abilities

# -------------------------------
# Functions for Grade Estimation
# -------------------------------

def sample_score(ability, difficulty, epsilon):
    diff = ability - difficulty
    sample = np.random.normal(diff, epsilon)
    # Apply sigmoid to bring back to (0,1)
    return 1 / (1 + np.exp(-sample))

def estimate_single_student_grade_soft_squared(ability_estimate, difficulties, epsilons):
    n_particles = 10000
    final_grades = []
    num_assns = len(difficulties)
    estimated_assn_scores = [0 for _ in range(num_assns)]
    for i in range(n_particles):
        scores = [] 
        ability = stats.norm.rvs(loc=ability_estimate['mu'], scale=ability_estimate['std'])
        # for each assn, we sample a score for the student to see how they would do
        # This allows us to see the confidence in the grade we are giving to the student by sampling mulptiple scores for assns they completed.
        for j in range(num_assns):
            difficulty, epsilon = difficulties[j], epsilons[j]
            score = sample_score(ability, difficulty, epsilon)
            estimated_assn_scores[j] += score
            scores.append(score)
        final_grades.append(np.mean(scores))
    estimated_assn_scores = [val / n_particles for val in estimated_assn_scores]
    return final_grades, estimated_assn_scores

def estimate_grades(ability_estimates, class_stats, observed, num_assn):
    student_grades = {}
    student_future_scores = {}
    difficulties = class_stats['difficulties']
    epsilons = class_stats['assn_epsilons']
    tasks = [
        (
            i,
            observed['students'][i]['scores'],
            ability_estimates[i],
            difficulties,
            epsilons
        )
        for i in ability_estimates
    ]
    with ProcessPoolExecutor(max_workers=6) as executor:
        future_to_student = {
            executor.submit(estimate_single_student_grade_soft_squared, *task[1:]): task[0]
            for task in tasks
        }
        for future in as_completed(future_to_student):
            student_id = future_to_student[future]
            try:
                grade_distribution, future_scores = future.result()
                student_grades[student_id] = grade_distribution
                student_future_scores[student_id] = future_scores
            except Exception as e:
                print(f"Error processing student {student_id}: {e}")
    return student_grades, student_future_scores

# -------------------------------
# Soft Grade Pipeline
# -------------------------------

def compute_soft_grades(observed):
    # Step 1: Estimate class statistics
    class_stats, total_distance = estimate_stats(observed, 0, 1)
    # Step 2: Infer student abilities
    ability_estimates = estimate_student_abilities(observed, class_stats)
    # Step 3: Estimate grades
    num_assn = len(observed['assignment_stats'])
    student_grades, student_future_scores = estimate_grades(ability_estimates, class_stats, observed, num_assn)
    return student_grades

# -------------------------------
# Main Routine
# -------------------------------

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python compute_soft_grades.py <csv_filename>")
        sys.exit(1)
        
    csv_filename = sys.argv[1]
    if not os.path.isfile(csv_filename):
        print(f"Error: file {csv_filename} does not exist.")
        sys.exit(1)
    
    # Read CSV file using pandas.
    df = pd.read_csv(csv_filename)
    
    # Ask teacher for the assessment column names (comma-separated).
    assessments_input = input("Enter the assessment column names (comma-separated): ")
    assessment_cols = [col.strip() for col in assessments_input.split(',')]
    
    # Ask teacher for the student id column name (default "student_id").
    student_id_col = input("Enter the student id column name (default 'student_id'): ").strip()
    if student_id_col == "":
        student_id_col = "student_id"
        
    # Check that columns exist
    for col in [student_id_col] + assessment_cols:
        if col not in df.columns:
            print(f"Error: column '{col}' not found in CSV.")
            sys.exit(1)
    
    ## Pre-process the data. We need to clip scores to be in the range [0.0005, 0.9995]. This is so the logit/sigmoid functions give reasonable values.
    for col in assessment_cols:
        df[col] = df[col].clip(lower=0.0005, upper=0.9995)

            
    # Build observed object.
    # For each assessment, compute mean and std across all students.
    assignment_stats = {}
    # Use the order in which the teacher entered the columns.
    for idx, col in enumerate(assessment_cols):
        col_values = df[col].values.astype(float)
        # If there is a nan value in the column, we need to ignore just that value for the mean and std of assignments. 
        col_values = col_values[~np.isnan(col_values)]
        
        assignment_stats[idx] = {
            'mean': np.mean(col_values),
            'std': np.std(col_values)
        }  

    # Build students dictionary.
    students = {}
    for _, row in df.iterrows():
        sid = str(row[student_id_col])
        # Get the scores in the order specified.
        scores = [float(row[col]) for col in assessment_cols]
        # check if any of these are nan
        if any(np.isnan(scores)):
            print("WARNING: Student", sid, "has missing scores.")
            continue

        students[sid] = {'scores': scores}  
    
    observed = {
        'assignment_stats': assignment_stats,
        'students': students
    }
    
    # Compute soft grades.
    print("Computing soft grade beliefs...")
    soft_grades = compute_soft_grades(observed)
    
    # Save results to a JSON file in the same directory.
    output_filename = "soft_grades.json"
    with open(output_filename, 'w') as f:
        json.dump(soft_grades, f, indent=2)
        
    print(f"Soft grade beliefs saved to {output_filename}")
