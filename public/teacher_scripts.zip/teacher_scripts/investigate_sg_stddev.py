import json 
import numpy as np
import matplotlib.pyplot as plt

def load_data(filename):
    with open(filename) as f:
        data = json.load(f)
    return data

def investigate_sg_stddev(data):
    student_id_to_stddev = {}
    for student_id, student_soft_grade in data.items():
        student_sg_var = np.std(student_soft_grade)
        student_id_to_stddev[student_id] = student_sg_var
    return student_id_to_stddev

def plot_variance_histogram(student_id_to_stddev):
    plt.hist(student_id_to_stddev.values(), bins=20, alpha=0.5, label='Standard Deviation of Soft Grade', color="#b879ff")
    plt.xlabel('Standard Deviation')
    plt.ylabel('Frequency')
    plt.title('Histogram of Standard Deviation of Soft Grade Distribution')
    plt.show()

def main():
    data = load_data("soft_grades.json")
    student_id_to_stddev = investigate_sg_stddev(data)
    # save this to a file 
    with open("student_id_to_stddev.json", "w") as f:
        json.dump(student_id_to_stddev, f)
    
    # plot the histogram of the variance
    plot_variance_histogram(student_id_to_stddev)

if __name__ == "__main__":
    main()
